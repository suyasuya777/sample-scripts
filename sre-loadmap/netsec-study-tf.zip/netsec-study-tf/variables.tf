variable "region" {
  description = "使用リージョン。1つに固定すること（消し忘れ防止）"
  type        = string
  default     = "ap-northeast-1"
}

variable "name_prefix" {
  description = "全リソース名の接頭辞"
  type        = string
  default     = "netsec-study"
}

variable "instance_type" {
  description = "EC2 のインスタンスタイプ（ARM。t4g.micro で 1台あたり約 $0.10/日）"
  type        = string
  default     = "t4g.micro"
}

variable "private_zone_name" {
  description = "12/8 の dig 演習で使うプライベートホストゾーン名"
  type        = string
  default     = "study.internal"
}

# ------------------------------------------------------------------
# 任意で有効にするもの（既定は無効。費用が上がるため）
# ------------------------------------------------------------------

variable "enable_ecr" {
  description = "12/18 の ECR 拡張スキャン演習用にリポジトリを作る。イメージの push は手動"
  type        = bool
  default     = false
}

variable "enable_tfstate_backend" {
  description = "12/17 の「state の S3 バックエンド設定」を点検する題材を作る"
  type        = bool
  default     = true
}

variable "enable_nat" {
  description = "12/7 の ErrorPortAllocation 用に NAT Gateway を作る。約 $1.5/日。その日のうちに戻すこと"
  type        = bool
  default     = false
}

variable "enable_rds" {
  description = "12/7 の max_connections 検算用に RDS を作る。約 $0.75/日。その日のうちに戻すこと"
  type        = bool
  default     = false
}

variable "db_password" {
  description = "検証用 RDS のパスワード（学習用。本番の値を入れないこと）"
  type        = string
  default     = "StudyOnly12345!"
  sensitive   = true
}
