# ==================================================================
# ログの保存先と Athena
#   12/9  ALB アクセスログの分析
#   12/11 Flow Logs と ALB ログの Athena クエリ
#   12/14 TLS バージョン分布の集計
# ==================================================================

resource "aws_s3_bucket" "logs" {
  bucket        = "${local.name}-logs-${local.account}"
  force_destroy = true # destroy 時にオブジェクトごと消す
  tags          = { Name = "${local.name}-logs" }
}

resource "aws_s3_bucket_public_access_block" "logs" {
  bucket                  = aws_s3_bucket.logs.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

data "aws_iam_policy_document" "logs" {
  # ALB アクセスログの配信
  statement {
    sid = "AlbAccessLogs"
    principals {
      type        = "AWS"
      identifiers = [data.aws_elb_service_account.this.arn]
    }
    actions   = ["s3:PutObject"]
    resources = ["${aws_s3_bucket.logs.arn}/alb/*"]
  }

  # Flow Logs の配信
  statement {
    sid = "FlowLogsPut"
    principals {
      type        = "Service"
      identifiers = ["delivery.logs.amazonaws.com"]
    }
    actions   = ["s3:PutObject"]
    resources = ["${aws_s3_bucket.logs.arn}/*"]
  }

  statement {
    sid = "FlowLogsAcl"
    principals {
      type        = "Service"
      identifiers = ["delivery.logs.amazonaws.com"]
    }
    actions   = ["s3:GetBucketAcl"]
    resources = [aws_s3_bucket.logs.arn]
  }
}

resource "aws_s3_bucket_policy" "logs" {
  bucket = aws_s3_bucket.logs.id
  policy = data.aws_iam_policy_document.logs.json
}

# ------------------------------------------------------------------
# Athena
#   スキャン量の上限を付けておく（誤って全期間を舐めても止まる）
# ------------------------------------------------------------------

resource "aws_athena_workgroup" "this" {
  name          = local.name
  force_destroy = true

  configuration {
    enforce_workgroup_configuration    = true
    publish_cloudwatch_metrics_enabled = false
    bytes_scanned_cutoff_per_query     = 1073741824 # 1GB

    result_configuration {
      output_location = "s3://${aws_s3_bucket.logs.bucket}/athena-results/"
    }
  }

  tags = { Name = local.name }
}

resource "aws_glue_catalog_database" "this" {
  name = replace(local.name, "-", "_")
}
