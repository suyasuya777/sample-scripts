#!/bin/bash
set -eux

# 12/7・12/11 で使うツール一式
dnf install -y tcpdump bind-utils nmap-ncat iproute

# ------------------------------------------------------------------
# 検証用の Web アプリ
#   /           200（ALB のヘルスチェックと通常アクセス）
#   /health     200
#   /slow?sec=N N秒待ってから 200（504 と target_processing_time の題材）
#   /status500  500（アプリが返した 5xx。elb_status_code と一致する）
#   /abort      応答を返さずに切断（ALB が生成する 502 の題材）
# ------------------------------------------------------------------
cat > /opt/netsec-app.py <<'PYEOF'
import socket
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, code, body=b"ok\n"):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)

        if u.path in ("/", "/health"):
            self._send(200)
        elif u.path == "/slow":
            try:
                sec = min(int(q.get("sec", ["3"])[0]), 120)
            except ValueError:
                sec = 3
            time.sleep(sec)
            self._send(200, b"slow ok\n")
        elif u.path == "/status500":
            self._send(500, b"application error\n")
        elif u.path == "/abort":
            # 何も返さずに切断する。ALB は応答を受け取れず 502 を生成する
            self.close_connection = True
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                self.connection.close()
            except OSError:
                pass
        else:
            self._send(404, b"not found\n")

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", 80), Handler).serve_forever()
PYEOF

cat > /etc/systemd/system/netsec-app.service <<'EOF'
[Unit]
Description=netsec study web app
After=network.target

[Service]
ExecStart=/usr/bin/python3 /opt/netsec-app.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now netsec-app
