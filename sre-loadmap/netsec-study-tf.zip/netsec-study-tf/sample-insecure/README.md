# 12/17 のスキャン演習用サンプル

**このフォルダの Terraform は、わざと危険な設定にしてあります。絶対に apply しないでください。**
tfsec / Checkov / gitleaks を実行して、検出結果を読むための題材です。

## 使い方

```bash
cd sample-insecure

# gitleaks で履歴を検査するため、git リポジトリにする
git init -q
git add -A
git -c user.email=study@example.com -c user.name=study commit -qm "initial"

# IaC スキャン
tfsec .
checkov -d . --compact

# シークレットの検出（--redact を必ず付ける）
gitleaks detect --source . --redact -v
```

## 仕込んである問題

| ファイル | 内容 | 検出するもの |
|---|---|---|
| `main.tf` | 22番を 0.0.0.0/0 に開放したセキュリティグループ | tfsec / Checkov |
| `main.tf` | 暗号化・バージョニングなしの S3 バケット | tfsec / Checkov |
| `main.tf` | パブリックアクセスブロックのない S3 バケット | tfsec / Checkov |
| `main.tf` | ログ記録のない ALB | tfsec / Checkov |
| `config/app.env` | ハードコードされたアクセスキー（**すべて架空の値**） | gitleaks |

`config/app.env` の値は実在しないダミーです。
