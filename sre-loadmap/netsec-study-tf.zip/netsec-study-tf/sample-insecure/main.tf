# わざと危険な設定にしたサンプル。apply しないこと。

provider "aws" {
  region = "ap-northeast-1"
}

# 問題1: SSH を全世界に開放している
resource "aws_security_group" "bad" {
  name        = "insecure-sample"
  description = "sample"
  vpc_id      = "vpc-00000000000000000"

  ingress {
    description = "SSH from anywhere"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# 問題2: 暗号化もバージョニングもパブリックアクセスブロックもない S3
resource "aws_s3_bucket" "bad" {
  bucket = "insecure-sample-bucket-000000000000"
}

# 問題3: アクセスログを取っていない ALB
resource "aws_lb" "bad" {
  name               = "insecure-sample"
  load_balancer_type = "application"
  subnets            = ["subnet-00000000000000000", "subnet-11111111111111111"]
}

# 問題4: 平文のパスワードを変数の既定値に書いている
variable "db_password" {
  type    = string
  default = "P@ssw0rd-hardcoded-123"
}
