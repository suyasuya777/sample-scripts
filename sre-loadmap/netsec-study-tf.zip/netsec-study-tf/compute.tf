# ==================================================================
# EC2 と ALB
#   12/7  ss / sysctl、ALB idle timeout
#   12/9  5xx の作り分け
#   12/10 ヘルスチェックと登録解除遅延
#   12/11 tcpdump、curl -w
#   12/14 openssl s_client（自己署名証明書を2枚入れて SNI を確認する）
#   12/18 SSM Session Manager
# ==================================================================

# ------------------------------------------------------------------
# EC2（SSM で入る。SSH ポートは開けない）
# ------------------------------------------------------------------

data "aws_iam_policy_document" "ec2_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "ec2" {
  name               = "${local.name}-ec2"
  assume_role_policy = data.aws_iam_policy_document.ec2_assume.json
}

resource "aws_iam_role_policy_attachment" "ec2_ssm" {
  role       = aws_iam_role.ec2.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_instance_profile" "ec2" {
  name = "${local.name}-ec2"
  role = aws_iam_role.ec2.name
}

# ALB の背後に置く Web サーバ
resource "aws_instance" "web" {
  ami                    = data.aws_ssm_parameter.al2023_arm.value
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public[0].id
  vpc_security_group_ids = [aws_security_group.web.id]
  iam_instance_profile   = aws_iam_instance_profile.ec2.name
  user_data              = file("${path.module}/user_data.sh")

  tags = { Name = "${local.name}-web" }
}

# 調査用。ここから web を叩いて REJECT を発生させる（12/11）
resource "aws_instance" "probe" {
  ami                    = data.aws_ssm_parameter.al2023_arm.value
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.public[1].id
  vpc_security_group_ids = [aws_security_group.probe.id]
  iam_instance_profile   = aws_iam_instance_profile.ec2.name
  user_data              = file("${path.module}/user_data.sh")

  tags = { Name = "${local.name}-probe" }
}

# ------------------------------------------------------------------
# 自己署名証明書を2枚（12/14 の SNI 確認用）
#   ドメインを持っていなくても TLS の演習ができるようにするため。
#   ブラウザや curl では検証エラーになるが、openssl s_client で
#   「どちらの証明書が返るか」を読むには十分。
# ------------------------------------------------------------------

resource "tls_private_key" "default" {
  algorithm = "RSA"
  rsa_bits  = 2048
}

resource "tls_self_signed_cert" "default" {
  private_key_pem = tls_private_key.default.private_key_pem

  subject {
    common_name  = "default.${var.private_zone_name}"
    organization = "netsec-study"
  }

  dns_names             = ["default.${var.private_zone_name}"]
  validity_period_hours = 720
  allowed_uses          = ["key_encipherment", "digital_signature", "server_auth"]
}

resource "aws_acm_certificate" "default" {
  private_key      = tls_private_key.default.private_key_pem
  certificate_body = tls_self_signed_cert.default.cert_pem
  tags             = { Name = "${local.name}-default" }

  lifecycle {
    create_before_destroy = true
  }
}

resource "tls_private_key" "app" {
  algorithm = "RSA"
  rsa_bits  = 2048
}

resource "tls_self_signed_cert" "app" {
  private_key_pem = tls_private_key.app.private_key_pem

  subject {
    common_name  = "app.${var.private_zone_name}"
    organization = "netsec-study"
  }

  dns_names             = ["app.${var.private_zone_name}"]
  validity_period_hours = 720
  allowed_uses          = ["key_encipherment", "digital_signature", "server_auth"]
}

resource "aws_acm_certificate" "app" {
  private_key      = tls_private_key.app.private_key_pem
  certificate_body = tls_self_signed_cert.app.cert_pem
  tags             = { Name = "${local.name}-app" }

  lifecycle {
    create_before_destroy = true
  }
}

# ------------------------------------------------------------------
# ALB
# ------------------------------------------------------------------

resource "aws_lb" "this" {
  name               = local.name
  load_balancer_type = "application"
  subnets            = aws_subnet.public[*].id
  security_groups    = [aws_security_group.alb.id]

  # 12/7 で読む値。既定と同じ60秒を明示しておく
  idle_timeout = 60

  access_logs {
    bucket  = aws_s3_bucket.logs.bucket
    prefix  = "alb"
    enabled = true
  }

  depends_on = [aws_s3_bucket_policy.logs]
  tags       = { Name = local.name }
}

resource "aws_lb_target_group" "this" {
  name        = local.name
  port        = 80
  protocol    = "HTTP"
  vpc_id      = aws_vpc.this.id
  target_type = "instance"

  # 12/10 で読む値。切り離し時間 = 10秒 × 2回 = 約20秒
  deregistration_delay = 30

  health_check {
    path                = "/health"
    interval            = 10
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 2
    matcher             = "200"
  }

  tags = { Name = local.name }
}

resource "aws_lb_target_group_attachment" "web" {
  target_group_arn = aws_lb_target_group.this.arn
  target_id        = aws_instance.web.id
  port             = 80
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.this.arn
  }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"

  # TLS 1.2 以上のみ許可。-tls1_1 での接続が失敗することを確認できる（12/14）
  ssl_policy      = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn = aws_acm_certificate.default.arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.this.arn
  }
}

# SNI で出し分けるための2枚目
resource "aws_lb_listener_certificate" "app" {
  listener_arn    = aws_lb_listener.https.arn
  certificate_arn = aws_acm_certificate.app.arn
}
