# ==================================================================
# 任意で作るもの
# ==================================================================

# ------------------------------------------------------------------
# 12/17 : state の S3 バックエンド設定を点検する題材
#   暗号化・バージョニング・パブリックアクセスブロック・ロックの4点が
#   そろった状態を作る。CLI で1つずつ確認する
# ------------------------------------------------------------------

resource "aws_s3_bucket" "tfstate" {
  count         = var.enable_tfstate_backend ? 1 : 0
  bucket        = "${local.name}-tfstate-${local.account}"
  force_destroy = true
  tags          = { Name = "${local.name}-tfstate" }
}

resource "aws_s3_bucket_versioning" "tfstate" {
  count  = var.enable_tfstate_backend ? 1 : 0
  bucket = aws_s3_bucket.tfstate[0].id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "tfstate" {
  count  = var.enable_tfstate_backend ? 1 : 0
  bucket = aws_s3_bucket.tfstate[0].id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "tfstate" {
  count                   = var.enable_tfstate_backend ? 1 : 0
  bucket                  = aws_s3_bucket.tfstate[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_dynamodb_table" "tflock" {
  count        = var.enable_tfstate_backend ? 1 : 0
  name         = "${local.name}-tflock"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }

  tags = { Name = "${local.name}-tflock" }
}

# ------------------------------------------------------------------
# 12/18 : ECR（既定では作らない）
#   拡張スキャンは Inspector の課金対象。イメージの push は手動
# ------------------------------------------------------------------

resource "aws_ecr_repository" "this" {
  count                = var.enable_ecr ? 1 : 0
  name                 = local.name
  force_delete         = true
  image_tag_mutability = "MUTABLE"

  tags = { Name = local.name }
}
