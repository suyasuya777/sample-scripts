# ==================================================================
# プライベートホストゾーン（12/8 の dig 演習）
#   TTL の違う2つのレコードを置き、キャッシュの効き方を比べる
# ==================================================================

resource "aws_route53_zone" "private" {
  name = var.private_zone_name

  vpc {
    vpc_id = aws_vpc.this.id
  }

  tags = { Name = local.name }
}

# TTL 300（長め）。切替時に待たされる側
resource "aws_route53_record" "app" {
  zone_id = aws_route53_zone.private.zone_id
  name    = "app.${var.private_zone_name}"
  type    = "A"
  ttl     = 300
  records = [aws_instance.web.private_ip]
}

# TTL 60（短め）。切替前に下げた状態を模したもの
resource "aws_route53_record" "short" {
  zone_id = aws_route53_zone.private.zone_id
  name    = "short.${var.private_zone_name}"
  type    = "A"
  ttl     = 60
  records = [aws_instance.web.private_ip]
}

# CNAME。dig の ANSWER SECTION が2行になる様子を見る
resource "aws_route53_record" "alias" {
  zone_id = aws_route53_zone.private.zone_id
  name    = "alias.${var.private_zone_name}"
  type    = "CNAME"
  ttl     = 300
  records = ["app.${var.private_zone_name}"]
}
