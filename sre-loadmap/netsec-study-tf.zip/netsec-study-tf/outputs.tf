output "alb_dns_name" {
  description = "curl / openssl の接続先"
  value       = aws_lb.this.dns_name
}

output "alb_arn" {
  description = "12/7 idle timeout、12/10 各種属性の取得に使う"
  value       = aws_lb.this.arn
}

output "target_group_arn" {
  description = "12/10 ヘルスチェックと登録解除遅延の取得に使う"
  value       = aws_lb_target_group.this.arn
}

output "web_instance_id" {
  description = "ss / sysctl / tcpdump を打つホスト（SSM で入る）"
  value       = aws_instance.web.id
}

output "web_private_ip" {
  description = "probe から REJECT を発生させる宛先"
  value       = aws_instance.web.private_ip
}

output "probe_instance_id" {
  description = "12/11 の REJECT 発生元"
  value       = aws_instance.probe.id
}

output "web_eni_id" {
  description = "12/11 の Athena クエリで絞り込む ENI"
  value       = aws_instance.web.primary_network_interface_id
}

output "log_bucket" {
  description = "ALB アクセスログと Flow Logs の保存先"
  value       = aws_s3_bucket.logs.bucket
}

output "athena_alb_log_location" {
  description = "ALB ログの Athena テーブルの LOCATION"
  value       = "s3://${aws_s3_bucket.logs.bucket}/alb/AWSLogs/${local.account}/elasticloadbalancing/${var.region}/"
}

output "athena_flowlog_location" {
  description = "Flow Logs の Athena テーブルの LOCATION"
  value       = "s3://${aws_s3_bucket.logs.bucket}/flowlogs/AWSLogs/${local.account}/vpcflowlogs/${var.region}/"
}

output "athena_workgroup" {
  value = aws_athena_workgroup.this.name
}

output "athena_database" {
  value = aws_glue_catalog_database.this.name
}

output "vpc_id" {
  value = aws_vpc.this.id
}

output "tiny_subnet_id" {
  description = "12/16 の空きIP確認用（/28）"
  value       = aws_subnet.tiny.id
}

output "nacl_demo_subnet_id" {
  description = "12/15 の NACL 点検用"
  value       = aws_subnet.nacl_demo.id
}

output "private_zone_name" {
  description = "12/8 の dig 演習で引く名前（app. / short. / alias. が引ける）"
  value       = var.private_zone_name
}

output "assume_role_arn" {
  description = "12/13 の aws sts assume-role の対象"
  value       = aws_iam_role.assume_demo.arn
}

output "secret_arn" {
  value = aws_secretsmanager_secret.db.arn
}

output "ecs_task_definition" {
  value = aws_ecs_task_definition.sample.family
}

output "iam_user1_access_key_id" {
  description = "12/6 に1回だけ使うキー（使用済みキーの題材）"
  value       = aws_iam_access_key.u1.id
}

output "iam_user1_secret_access_key" {
  description = "terraform output -raw iam_user1_secret_access_key で取り出す"
  value       = aws_iam_access_key.u1.secret
  sensitive   = true
}

output "tfstate_bucket" {
  description = "12/17 のバックエンド設定点検の対象"
  value       = try(aws_s3_bucket.tfstate[0].id, null)
}

output "tflock_table" {
  value = try(aws_dynamodb_table.tflock[0].name, null)
}

output "ecr_repository" {
  value = try(aws_ecr_repository.this[0].name, null)
}

# --- 当日だけ作るもの ---

output "private_subnet_ids" {
  description = "NAT が無い間は外に出られないサブネット（12/15 の題材）"
  value       = aws_subnet.private[*].id
}

output "private_route_table_id" {
  value = aws_route_table.private.id
}

output "db_parameter_group" {
  description = "12/7 の max_connections を読む先（RDS を作らなくても存在する）"
  value       = aws_db_parameter_group.this.name
}

output "nat_gateway_id" {
  description = "12/7 の ErrorPortAllocation アラームの Dimension 値"
  value       = try(aws_nat_gateway.this[0].id, null)
}

output "rds_endpoint" {
  value = try(aws_db_instance.this[0].address, null)
}
