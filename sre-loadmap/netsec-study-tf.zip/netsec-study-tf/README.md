# ネットワーク・セキュリティ学習 テスト環境 構築手順

対象：`【SRE】ネットワーク・セキュリティ コマンド集.md` の【実機】【調査】項目を、自分のAWSアカウントで実行するための環境
期間：**12/6（日）に作り、12/20（日）に壊す**（約2週間）
費用：**約 $1.5/日、合計 $20〜25**
方針：**【実機】【調査】はすべてこの環境で実施する。** 担当システムでは権限が無くて打てない項目や、平常時には現れない事象（502・REJECT・TIME_WAIT の山）を、ここで再現する

**コマンドはすべて WSL2 の Ubuntu で実行します。**

**済管理のルール**：`□` を `☑` に書き換えて進めます（進捗表・コマンド集と同じ記法）。
見出しの `□` はその日全体の済、項目の `□` は個別作業の済です。

| 済 | 日付 | この手順書でやること | 章 |
|---|---|---|---|
| □ | 11/23〜11/30 | 事前準備（ツール・認証・予算アラート・`terraform init`） | §2 |
| □ | **12/6（日）** | **構築**、Athena テーブル作成、題材の仕込み | §3・§5 |
| □ | 12/7（月） | NAT と RDS を当日だけ作って壊す | §6 |
| □ | 12/8（火） | VPC内から `dig`、ALBログの再生成 | §6 |
| □ | 12/9（水） | 5xx の3パターンを確認 | §6 |
| □ | 12/10（木） | ALB・ターゲットグループの設定値を取得 | §6 |
| □ | 12/11（金） | REJECT の生成、`tcpdump` | §6 |
| □ | 12/13（日） | AssumeRole、タスク定義 | §6 |
| □ | 12/14（月） | 自己署名証明書で SNI を確認 | §6 |
| □ | 12/15（火） | ルートテーブルと NACL の点検 | §6 |
| □ | 12/16（水） | `/28` サブネットで必要IP数を逆算 | §6 |
| □ | 12/17（木） | サンプルのスキャン、バックエンド4点 | §6 |
| □ | 12/18（金） | SSM 接続、ECR（任意） | §6 |
| □ | **12/20（日）** | **破棄**とチェックリスト | §9 |

> boto3 の環境で問題になった `local-exec`（Terraform の中から bash を呼ぶ処理）は、この環境では一切使っていません。データの仕込みはすべて、下記のスクリプトとコマンドで行います。

---

## 1. この環境で何が再現できるか

| 日付 | コマンド集の項目 | この環境で用意しているもの |
|---|---|---|
| 12/7 | `ss` で TIME_WAIT を数える | 接続を大量に開閉するスクリプト |
| 12/7 | ALB idle timeout と Keep-Alive | idle_timeout=60 を明示した ALB |
| 12/8 | `dig` の打ち分け、TTL の読み取り | TTL 300 / 60 のレコードを持つプライベートホストゾーン |
| 12/9 | 5xx の区別、`target_processing_time` = -1 | 4種類の 5xx を作り分けられる Web アプリ |
| 12/10 | 切り離し時間、登録解除遅延 | 間隔10秒・閾値2・登録解除30秒のターゲットグループ |
| 12/11 | `tcpdump`、`curl -w` | SSM で入れる EC2 2台 |
| 12/11 | Flow Logs の REJECT 抽出 | 許可されていないポートを叩いて REJECT を作るスクリプト |
| 12/13 | `aws sts assume-role` | 同一アカウントから引き受けられるロール |
| 12/13 | 未使用キーを数える | 使用済みキーと未使用キーを持つ IAM ユーザ2名 |
| 12/13 | タスク定義でシークレットを参照 | `secrets` で渡す ECS タスク定義（起動はしない） |
| 12/14 | `openssl s_client`、SNI の確認 | 自己署名証明書を2枚入れた HTTPS リスナー |
| 12/15 | ルートテーブル・SG・NACL の点検 | 経路の異なるルートテーブル2つと、番号付き NACL |
| 12/16 | 空きIPの確認と逆算 | `/28` の小さいサブネット（使えるIPは11個） |
| 12/17 | tfsec / Checkov / gitleaks | わざと危険にしたサンプルリポジトリ |
| 12/17 | state バックエンドの4点確認 | 暗号化・バージョニング・PAB・ロックをそろえた S3 と DynamoDB |
| 12/18 | SSM Session Manager | SSM で入れる EC2 |
| 12/20 | CloudTrail の検索 | この環境の構築操作そのものが証跡になる |

### この環境で用意できない値

次の4つは、実稼働のシステムでないと出てきません。**仮の値を置いて、手順と計算式を確立するところまで**が到達点です（進捗表の該当日にも注記してあります）。

| 用意できないもの | 使う日 | 代わりにやること |
|---|---|---|
| アプリ側の Keep-Alive | 12/7 | ALB の60秒と並べ、**外側＜内側**の判定手順を作る |
| コネクションプールの設定値 | 12/7 | `max_connections` は実値、プール数とタスク数は仮置きで検算 |
| CloudFront のタイムアウト | 12/10 | ALB と DB の実値＋仮の値で、全層のタイムアウト表を完成させる |
| 実稼働のトラフィック量 | 12/15 | 仮の使用率を置いて、AZ障害時の試算手順を確立する |

現場で値が取れるようになった時点で差し替えれば、そのまま実務で使えます。

### 当日だけ作って当日壊すもの

**NAT Gateway と RDS は、高い割に使う日が限られる**ので、常時は作りません。12/7 のその日だけ作り、終わったら戻します。

| 対象 | 使う場面 | 費用 | 作成・削除にかかる時間 |
|---|---|---|---|
| □ | **NAT Gateway** | 12/7 `ErrorPortAllocation` のアラーム作成、12/15 の経路の題材 | **約 $1.5/日**（数時間なら $0.3 程度） | 作成2分・削除2分 |
| □ | **RDS** | 12/7 `max_connections` の実値確認 | **約 $0.75/日**（数時間なら $0.2 程度） | 作成10分・削除5〜10分 |

`terraform.tfvars` は書き換えません。コマンドのオプションで有効にします（手順は6章の 12/7）。

**RDS のパラメータグループだけは常時作ってあります（無料）。** `max_connections` の設定式はこれを見れば読めるので、**インスタンスを作らずに済ませることもできます。** 実際に `SHOW max_connections` を打って実値を見たい場合だけ、インスタンスを作ってください。

---

## □ 2. 事前準備（12/6 より前に1回だけ）

- □ **2-1. ツール**

```bash
sudo apt update
sudo apt install -y terraform unzip jq iproute2 tcpdump dnsutils curl openssl

# Session Manager プラグイン（EC2 に入るために必要）
curl -o /tmp/session-manager-plugin.deb \
  "https://s3.amazonaws.com/session-manager-downloads/plugin/latest/ubuntu_64bit/session-manager-plugin.deb"
sudo dpkg -i /tmp/session-manager-plugin.deb

# 確認
terraform version; aws --version; session-manager-plugin --version
```

Terraform が入っていない場合は、HashiCorp のリポジトリを追加してから入れます（boto3 環境の手順書 §1-1 と同じ）。

- □ **2-2. 認証と予算アラート**

```bash
aws sts get-caller-identity          # 管理者権限のIAMユーザであること
export AWS_DEFAULT_REGION=ap-northeast-1
```

```bash
ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
cat > /tmp/budget.json <<'EOF'
{ "BudgetName": "netsec-study", "BudgetLimit": { "Amount": "30", "Unit": "USD" },
  "TimeUnit": "MONTHLY", "BudgetType": "COST" }
EOF
cat > /tmp/notify.json <<'EOF'
[{ "Notification": { "NotificationType": "ACTUAL", "ComparisonOperator": "GREATER_THAN",
     "Threshold": 80, "ThresholdType": "PERCENTAGE" },
   "Subscribers": [{ "SubscriptionType": "EMAIL", "Address": "自分のメールアドレス" }] }]
EOF
aws budgets create-budget --account-id "$ACCOUNT" \
  --budget file:///tmp/budget.json --notifications-with-subscribers file:///tmp/notify.json
```

- □ **2-3. Terraform 一式を置く**

```bash
cd ~
unzip -q "/mnt/c/Users/<Windowsのユーザ名>/Downloads/netsec-study-tf.zip"
mv ./netsec-study-tf ~/netsec-study-tf 2>/dev/null || true
cd ~/netsec-study-tf
terraform init
terraform plan          # エラーが出ないことだけ確認。apply はまだしない
```

---

## □ 3. 構築（12/6・日）

- □ **3-1. 作る**

```bash
cd ~/netsec-study-tf
terraform apply         # 約5分
```

一覧を読んでから `yes` を入力します。完了したら応答を確認します。

```bash
curl -I "http://$(terraform output -raw alb_dns_name)"     # HTTP/1.1 200 OK
```

200 が返らない場合、EC2 の起動処理（ツールの導入とアプリの起動）がまだ終わっていない可能性があります。2〜3分おいて再確認してください。

- □ **3-2. 仕込み（当日中にやっておく）**

  - □ **① user1 のキーを1回だけ使う**（12/13 の「使用済み／未使用」の差を作る）

```bash
AWS_ACCESS_KEY_ID=$(terraform output -raw iam_user1_access_key_id) \
AWS_SECRET_ACCESS_KEY=$(terraform output -raw iam_user1_secret_access_key) \
AWS_SESSION_TOKEN= \
aws sts get-caller-identity
```

user1 の ARN が返れば成功です（権限は何も付いていないので、これ以外は失敗します）。**user2 のキーは使わないでください。** 認証情報レポートへの反映には数時間かかります。

  - □ **② Athena のテーブルを2つ作る**（5章の DDL を実行）

  - □ **③ ALB にアクセスを流し始める**

```bash
bash scripts/gen_alb_logs.sh
```

正常な200、アプリが返す500、ALBが生成する502、ターゲット不在の503、TLS 1.2と1.3のアクセスを一通り作ります。**約2分かかります**（ヘルスチェックの待ち時間を含む）。

ログが S3 に届くまで5〜10分かかるので、**12/9 に使うぶんは12/8 までにもう一度流しておく**と確実です。

---

## 4. コマンド集の読み替え表

コマンド集は `<ALBのARN>` のようなプレースホルダで書いてあります。この環境では次のコマンドで実際の値が取れます。**`~/netsec-study-tf` で実行してください。**

| コマンド集の表記 | この環境での取得方法 |
|---|---|
| `<ALBのARN>` | `terraform output -raw alb_arn` |
| `<ターゲットグループのARN>` | `terraform output -raw target_group_arn` |
| `<インスタンスID>` | `terraform output -raw web_instance_id` |
| `<VPC ID>` | `terraform output -raw vpc_id` |
| `<サブネットID>`（NACL点検用） | `terraform output -raw nacl_demo_subnet_id` |
| `<SG ID>` | `aws ec2 describe-security-groups --filters Name=tag:Project,Values=netsec-study --query 'SecurityGroups[].[GroupName,GroupId]' --output table` |
| `<state用バケット>` | `terraform output -raw tfstate_bucket` |
| `<ロック用テーブル>` | `terraform output -raw tflock_table` |
| ALB ログの Athena テーブル | `netsec_study.alb_logs` |
| Flow Logs の Athena テーブル | `netsec_study.flow_logs` |

**EC2 に入るとき**（`ss` `sysctl` `tcpdump` `dig` を打つ日）：

```bash
aws ssm start-session --target "$(terraform output -raw web_instance_id)"
```

---

## □ 5. Athena のテーブル定義（12/6 に実行）

マネジメントコンソールの Athena を開き、**ワークグループを `netsec-study` に切り替えてから**実行します。`【LOCATION】` は下のコマンドの出力に置き換えてください。

```bash
terraform output -raw athena_alb_log_location     # ALB ログ用
terraform output -raw athena_flowlog_location     # Flow Logs 用
```

- □ **ALB アクセスログ**

```sql
CREATE EXTERNAL TABLE netsec_study.alb_logs (
  type string, time string, elb string,
  client_ip_port string, target_ip_port string,
  request_processing_time double, target_processing_time double,
  response_processing_time double,
  elb_status_code int, target_status_code string,
  received_bytes bigint, sent_bytes bigint,
  request string, user_agent string,
  ssl_cipher string, ssl_protocol string,
  target_group_arn string, trace_id string,
  domain_name string, chosen_cert_arn string,
  matched_rule_priority string, request_creation_time string,
  actions_executed string, redirect_url string,
  lambda_error_reason string, target_port_list string,
  target_status_code_list string, classification string,
  classification_reason string
)
PARTITIONED BY (dt string)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.RegexSerDe'
WITH SERDEPROPERTIES (
  'serialization.format' = '1',
  'input.regex' = '([^ ]*) ([^ ]*) ([^ ]*) ([^ ]*):([0-9]*) ([^ ]*)[:-]([0-9]*) ([-.0-9]*) ([-.0-9]*) ([-.0-9]*) (|[-0-9]*) (-|[-0-9]*) ([-0-9]*) ([-0-9]*) \"([^\"]*)\" \"([^\"]*)\" ([A-Z0-9-_]+) ([A-Za-z0-9.-]*) ([^ ]*) \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" ([-.0-9]*) ([^ ]*) \"([^\"]*)\" \"([^\"]*)\" \"([^ ]*)\" \"([^\\s]+?)\" \"([^\\s]+)\" \"([^ ]*)\" \"([^ ]*)\"'
)
LOCATION '【ALBログのLOCATION】'
TBLPROPERTIES (
  'projection.enabled' = 'true',
  'projection.dt.type' = 'date',
  'projection.dt.range' = '2026/12/06,NOW',
  'projection.dt.format' = 'yyyy/MM/dd',
  'projection.dt.interval' = '1',
  'projection.dt.interval.unit' = 'DAYS',
  'storage.location.template' = '【ALBログのLOCATION】${dt}'
);
```

- □ **VPC Flow Logs（既定フォーマット）**

```sql
CREATE EXTERNAL TABLE netsec_study.flow_logs (
  version int, account_id string, interface_id string,
  srcaddr string, dstaddr string, srcport int, dstport int,
  protocol bigint, packets bigint, bytes bigint,
  start bigint, `end` bigint, action string, log_status string
)
PARTITIONED BY (dt string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ' '
LOCATION '【FlowLogsのLOCATION】'
TBLPROPERTIES (
  'skip.header.line.count' = '1',
  'projection.enabled' = 'true',
  'projection.dt.type' = 'date',
  'projection.dt.range' = '2026/12/06,NOW',
  'projection.dt.format' = 'yyyy/MM/dd',
  'projection.dt.interval' = '1',
  'projection.dt.interval.unit' = 'DAYS',
  'storage.location.template' = '【FlowLogsのLOCATION】${dt}'
);
```

`end` は予約語なので、クエリで使うときもバッククォートで囲みます。

---

## 6. 日別の追加作業

コマンド集の各日の項目を、4章の読み替え表を使って打ちます。**この環境でだけ必要になる追加の操作**が、次の日にあります。

### □ 12/7（月）トランスポート層

**この日だけ NAT Gateway と RDS を作ります。**

- □ **① 学習の最初に作る**（RDS の作成に約10分。待ち時間はアプリの四択に充てる）

```bash
cd ~/netsec-study-tf
terraform apply -var="enable_nat=true" -var="enable_rds=true"
```

一覧に **NAT Gateway・EIP・ルート1本・RDS インスタンス**が作成対象として出ていることを確認して `yes` を入力します。

- □ **② TIME_WAIT を作って数える**

```bash
bash scripts/gen_timewait.sh
```

実行前後の件数が表示されます。その後 EC2 に入って、コマンド集の `ss -s` や `sysctl` を自分の手で打ってください。

- □ **③ `max_connections` を検算する**

設定式はパラメータグループから読めます。

```bash
aws rds describe-db-parameters --db-parameter-group-name "$(terraform output -raw db_parameter_group)" \
  --query "Parameters[?ParameterName=='max_connections'].[ParameterValue,ApplyType]" --output text
```

`LEAST({DBInstanceClassMemory/9531392},5000)` のような式が返ります。**実値は接続して確認します。**

```bash
aws ssm start-session --target "$(terraform output -raw web_instance_id)"
```

```bash
sudo dnf install -y postgresql16 || sudo dnf install -y postgresql15
PGPASSWORD='StudyOnly12345!' psql -h <rds_endpoint> -U postgres -d study -c "SHOW max_connections;"
exit
```

`<rds_endpoint>` は `terraform output -raw rds_endpoint` で取れます。db.t4g.micro（1GB）なら100前後になるはずです。**「プール最大数 × タスク数 ≦ この値」**で検算します。

- □ **④ ErrorPortAllocation のアラームを作る**

```bash
aws cloudwatch put-metric-alarm \
  --alarm-name netsec-study-nat-port-allocation \
  --namespace AWS/NATGateway --metric-name ErrorPortAllocation \
  --dimensions Name=NatGatewayId,Value="$(terraform output -raw nat_gateway_id)" \
  --statistic Sum --period 300 --evaluation-periods 1 \
  --threshold 0 --comparison-operator GreaterThanThreshold

aws cloudwatch describe-alarms --alarm-names netsec-study-nat-port-allocation \
  --query 'MetricAlarms[].[AlarmName,StateValue]' --output table

# 確認できたら消す
aws cloudwatch delete-alarms --alarm-names netsec-study-nat-port-allocation
```

作成直後は `INSUFFICIENT_DATA` です。**このメトリクスは、NAT の背後から同一の宛先へ大量に接続してポートを使い切ったときにだけ値が入ります。** 学習環境で枯渇させるのは現実的ではないので、**「どのメトリクスを、どの Dimension で監視すればよいか」を確かめるところまで**が目的です。

- □ **⑤ その日のうちに壊す**

```bash
terraform apply
```

一覧に **NAT Gateway・EIP・ルート・RDS が削除（destroy）対象**として出ていることを確認して `yes` を入力します。RDS の削除に5〜10分かかります。完了後、残っていないことを確認します。

```bash
aws ec2 describe-nat-gateways --filter Name=state,Values=available \
  --query 'NatGateways[].NatGatewayId'                                  # [] ならOK
aws rds describe-db-instances --query 'DBInstances[].DBInstanceIdentifier'  # [] ならOK
```

**消し忘れると NAT Gateway が $1.5/日、RDS が $0.75/日**かかり続けます。ここまでやってその日の作業完了です。

> 12/15 の「最長一致で経路を追う」を、より本番に近い形（プライベートサブネットが NAT 経由で外に出る状態）でやりたい場合は、同じ方法でその日も NAT を作れます。追加で $0.3 程度です。NAT が無い状態でも、**外への経路を持たないプライベートサブネット**として点検の題材にはなります。

### □ 12/8（火）名前解決・DNS

- □ **① VPC内の EC2 から `dig` を打つ**
- □ **② ALB アクセスログを再生成する**（12/9 で使う）

プライベートホストゾーンは **VPC の中からしか引けません。** EC2 に入って打ちます。

```bash
aws ssm start-session --target "$(terraform output -raw web_instance_id)"
```

```bash
# TTL 300 のレコード（数秒おいて2回打つと、残り秒数が減る）
dig app.study.internal +noall +answer
# TTL 60 のレコード（切替前に下げた状態）
dig short.study.internal +noall +answer
# CNAME（ANSWER SECTION が2行になる）
dig alias.study.internal +noall +answer
# VPC のリゾルバに直接聞く
dig @169.254.169.253 app.study.internal +noall +answer
```

`dig @8.8.8.8` `+trace` は外部の名前（example.com など）で試します。

**②** は手元（WSL2）に戻ってから実行します。翌日の Athena で使うログを、余裕をもって貯めておくためです。

```bash
exit                                # EC2 から抜ける
cd ~/netsec-study-tf
bash scripts/gen_alb_logs.sh        # 約2分
```

### □ 12/9（水）HTTP と上位プロトコル

- □ **① ログが届いていることを確認する**
- □ **② 5xx の3パターンを Athena で読み分ける**

**前日までに `gen_alb_logs.sh` を流してあること。** 流していなければ、朝に実行して10分待ってから Athena を使ってください。

作られる行の対応は次のとおりです。

| 作った操作 | ログ上の見え方 |
|---|---|
| `/status500` | `elb_status_code` = 500、`target_status_code` = 500（**アプリが返した 5xx**） |
| `/abort` | `elb_status_code` = 502、`target_status_code` = `-`（**ALB が生成した 5xx**） |
| アプリ停止中のアクセス | `elb_status_code` = 503、`target_processing_time` = **-1** |

### □ 12/10（木）負荷分散・トラフィック制御

- □ **① ALB とターゲットグループの設定値を取得する**
- □ **② 切り離し時間を算出する**

この日は新しく作るものはありません。コマンド集 12/10 のコマンドを、4章の読み替え表を使って打ちます。

```bash
cd ~/netsec-study-tf
aws elbv2 describe-target-groups --load-balancer-arn "$(terraform output -raw alb_arn)" \
  --query 'TargetGroups[].[TargetGroupName,HealthCheckIntervalSeconds,UnhealthyThresholdCount,HealthyThresholdCount]' --output table

aws elbv2 describe-target-group-attributes --target-group-arn "$(terraform output -raw target_group_arn)" \
  --query "Attributes[?Key=='deregistration_delay.timeout_seconds']" --output text
```

この環境の値は **間隔10秒・異常閾値2・登録解除30秒**です。切り離しまでは 10 × 2 = **約20秒**になります。

### □ 12/11（金）ネットワーク可観測性

- □ **① Flow Logs に REJECT を生成する**
- □ **② Athena で ENI を絞って抽出する**
- □ **③ EC2 の中で `tcpdump` を打つ**

```bash
# Flow Logs に REJECT を作る
bash scripts/gen_reject.sh
```

出力された ENI ID を控え、10分待ってから Athena で検索します。

```sql
SELECT from_unixtime(start) AS t, srcaddr, srcport, dstaddr, dstport, protocol, action
FROM netsec_study.flow_logs
WHERE interface_id = '【gen_reject.sh が表示した ENI】'
  AND action = 'REJECT'
ORDER BY start DESC
LIMIT 50;
```

`tcpdump` は EC2 に入って打ちます。**別のターミナルから ALB を叩きながら**実行すると、パケットが流れます。

```bash
# ターミナル1（EC2 の中）
sudo tcpdump -i any -nn 'tcp[tcpflags] & (tcp-syn) != 0' -c 10
# ターミナル2（手元）
curl -s -o /dev/null "http://$(terraform output -raw alb_dns_name)/"
```

### □ 12/13（日）IAM ＋ シークレット

- □ **① `aws sts assume-role` を実行し、一時認証情報の中身と有効期限を見る**
- □ **② 認証情報レポートで user1（使用済み）と user2（未使用）の差を見る**
- □ **③ タスク定義の `secrets` の書き方を読む**

```bash
# AssumeRole の対象
terraform output -raw assume_role_arn
# タスク定義（secrets の書き方を読む）
aws ecs describe-task-definition --task-definition "$(terraform output -raw ecs_task_definition)" \
  --query 'taskDefinition.containerDefinitions[].{secrets:secrets,env:environment}'
```

認証情報レポートでは、**user1 が「使用済み」、user2 が「未使用」**として出るはずです。

### □ 12/14（月）TLS / PKI

- □ **① SNI の有無で返る証明書が変わることを確認する**
- □ **② 証明書チェーンとプロトコル・暗号スイートを読む**
- □ **③ リスナーのセキュリティポリシーを CLI で確認する**

**証明書は自己署名です。** `Verify return code` は 0 以外（18 や 19）になりますが、プロトコル・暗号スイート・SNI の確認には支障ありません。むしろ検証エラーの読み方を覚える題材になります。

```bash
ALB=$(terraform output -raw alb_dns_name)

# SNI あり → app の証明書が返る
openssl s_client -connect ${ALB}:443 -servername app.study.internal </dev/null 2>/dev/null | \
  openssl x509 -noout -subject
# SNI なし → default の証明書が返る
openssl s_client -connect ${ALB}:443 -noservername </dev/null 2>/dev/null | \
  openssl x509 -noout -subject
```

リスナーのポリシーは TLS 1.2 以上のみ許可にしてあります。古いバージョンでの接続が拒否されることを確認してください。ただし**手元の OpenSSL 3.x が TLS 1.0/1.1 を既定で無効にしている場合、サーバに届く前にクライアント側で失敗します。** その場合はポリシーの中身を CLI で確認する方法に切り替えてください（コマンド集 12/14）。

### □ 12/15（火）クラウドネットワーク設計

- □ **① ルートテーブル2種の違いを見る**
- □ **② NACL の番号順の評価を読む**
- □ **③ 必要なら NAT を足して、経路が増える様子を見る（任意）**

```bash
cd ~/netsec-study-tf

# 公開用（IGW 向きの 0.0.0.0/0 がある）と、プライベート用（経路なし）の2種類
aws ec2 describe-route-tables --filters Name=vpc-id,Values="$(terraform output -raw vpc_id)" \
  --query 'RouteTables[].{RT:RouteTableId,Subnets:Associations[].SubnetId,Routes:Routes[].[DestinationCidrBlock,GatewayId,NatGatewayId]}'

# NACL（100番で80を許可、110番で22を拒否、送信側で戻りのポートを許可）
aws ec2 describe-network-acls \
  --filters Name=association.subnet-id,Values="$(terraform output -raw nacl_demo_subnet_id)" \
  --query 'NetworkAcls[].Entries[].[RuleNumber,Protocol,RuleAction,CidrBlock,Egress,PortRange]' --output table
```

**プライベートサブネットには外向きの経路がありません。** ③ で NAT を足すと `0.0.0.0/0` が1本増え、最長一致の題材がより本番に近くなります（12/7 と同じ方法、追加 $0.3 程度）。

```bash
terraform apply -var="enable_nat=true"    # 経路が1本増える
# 確認が終わったら
terraform apply                           # 元に戻す（NAT を壊す）
```

### □ 12/16（水）キャパシティ

- □ **① サブネットごとの空きIP数を取得する**
- □ **② `/28` を題材に必要IP数を逆算する**

```bash
aws ec2 describe-subnets --filters Name=vpc-id,Values="$(terraform output -raw vpc_id)" \
  --query 'Subnets[].[SubnetId,CidrBlock,AvailableIpAddressCount]' --output table
```

`/28` のサブネットは **使えるIPが11個**（AWS が5個予約）です。ここを題材に、必要IP数の逆算をしてください。

### □ 12/17（木）サプライチェーン

- □ **① `sample-insecure` を git リポジトリにする**
- □ **② tfsec / Checkov を実行する**
- □ **③ gitleaks で履歴を検査する（`--redact` を必ず付ける）**
- □ **④ state バックエンドの4点（暗号化・バージョニング・PAB・ロック）を確認する**

```bash
cd ~/netsec-study-tf/sample-insecure
# README.md のとおり git init → commit してからスキャンする
```

state バックエンドの4点確認は、作った S3 と DynamoDB に対して打ちます（4章の読み替え表）。

### □ 12/18（金）脆弱性・境界防御

- □ **① SSM Session Manager で EC2 に接続する**
- □ **② ECR の拡張スキャンを試す（任意。Inspector の課金が発生）**
- □ **③ ②を試した場合は、その日のうちに無効化してリポジトリも消す**

```bash
aws ssm start-session --target "$(terraform output -raw web_instance_id)"
```

ECR は既定では作りません。試す場合は次の手順です。**Inspector の課金が発生します。**

```bash
# 1. リポジトリを作る
terraform apply -var="enable_ecr=true"

# 2. 古いイメージを push する（Docker が必要）
REPO=$(terraform output -raw ecr_repository)
ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
aws ecr get-login-password | docker login --username AWS --password-stdin ${ACCOUNT}.dkr.ecr.ap-northeast-1.amazonaws.com
docker pull python:3.9-slim            # 古めのイメージほど検出が出る
docker tag python:3.9-slim ${ACCOUNT}.dkr.ecr.ap-northeast-1.amazonaws.com/${REPO}:old
docker push ${ACCOUNT}.dkr.ecr.ap-northeast-1.amazonaws.com/${REPO}:old

# 3. 拡張スキャンを有効化（コマンド集 12/18）
# 4. 確認後に無効化し、リポジトリも消す
aws inspector2 disable --resource-types ECR
terraform apply -var="enable_ecr=false"
```

### □ 12/20（日）監査ログ・脅威検知

- □ **① CloudTrail でこの環境の構築操作を検索する**
- □ **② Security Hub を試す（任意。AWS Config の課金が発生）**
- □ **③ ②を試した場合は、その日のうちに無効化する**
- □ **④ 環境を破棄する（§9）**

**CloudTrail はこの環境の構築操作がそのまま証跡になっています。**

```bash
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=EventName,AttributeValue=CreateSecurityGroup \
  --query 'Events[].[EventTime,Username,Resources[0].ResourceName]' --output table
```

**Security Hub は既定では有効にしていません。** 有効化すると AWS Config の記録も必要になり、月に数ドルかかります。試す場合は当日に有効化し、確認が終わったら無効化してください。

```bash
aws securityhub enable-security-hub --enable-default-standards
# 確認後
aws securityhub disable-security-hub
```

---

## 7. 注意事項

- **ALB は全世界に開放しています。** 返すのは `ok` だけの検証用アプリですが、学習期間が終わったら必ず壊してください
- **`terraform.tfstate` に機密が入ります。** IAM ユーザのシークレットキー、自己署名証明書の秘密鍵、Secrets Manager の値が平文で保存されます。共有しないでください
- **ALB アクセスログの配信は5分間隔、Flow Logs は最大10分**かかります。流した直後に Athena で検索しても出ません
- **Athena のワークグループにスキャン量の上限（1GB/クエリ）を設定してあります。** 超えるとクエリが止まりますが、これは想定どおりの動作です
- **`tcpdump` は EC2 の中で打ちます。** 手元の WSL2 で打っても、WSL2 自身の通信しか見えません
- **NAT Gateway と RDS は、作った日のうちに必ず戻してください。** `terraform.tfvars` を書き換えず `-var` で有効にしているのは、戻し忘れても次の `terraform apply` で自動的に削除されるようにするためです
- **12/20 に壊します。** 口述中心の第4期（12/21〜1/10）では環境は不要です

---

## 8. 費用

| 項目 | 概算 |
|---|---|
| ALB | $0.58/日 |
| EC2 t4g.micro × 2（パブリックIPを含む） | $0.75/日 |
| Route 53 プライベートホストゾーン | $0.50/月 |
| Secrets Manager | $0.40/月 |
| S3・Flow Logs・Athena・DynamoDB | 合計で $1 未満 |
| NAT Gateway（12/7 に数時間だけ） | 約 $0.3 |
| RDS（12/7 に数時間だけ） | 約 $0.2 |
| **合計（12/6〜12/20 の15日）** | **約 $20〜25** |

想定を超えるとしたら、**壊し忘れ**か、ECR 拡張スキャン（Inspector）か Security Hub の有効化したままです。

---

## □ 9. 破棄（12/20・日）

- □ **① `terraform destroy` を実行する**
- □ **② 下のチェックリストをすべて確認する**
- □ **③ 予算アラートを削除する（任意）**

```bash
cd ~/netsec-study-tf
terraform destroy       # 約5分
```

一覧を確認して `yes` を入力します。そのあと、**Terraform で消えないもの**を確認します。**すべて空（または結果なし）になれば完了です。**

| 済 | 対象 | 確認コマンド |
|---|---|---|
| □ | EC2 とALB | `aws ec2 describe-instances --filters Name=tag:Project,Values=netsec-study Name=instance-state-name,Values=running --query 'Reservations[].Instances[].InstanceId'` |
| □ | **NAT Gateway**（12/7 に作った場合） | `aws ec2 describe-nat-gateways --filter Name=state,Values=available --query 'NatGateways[].NatGatewayId'` |
| □ | **Elastic IP** | `aws ec2 describe-addresses --query 'Addresses[].[PublicIp,AssociationId]' --output table` |
| □ | **RDS**（12/7 に作った場合） | `aws rds describe-db-instances --query 'DBInstances[].DBInstanceIdentifier'` |
| □ | RDS スナップショット | `aws rds describe-db-snapshots --snapshot-type manual --query 'DBSnapshots[].DBSnapshotIdentifier'` |
| □ | タグ付きリソース全般 | `aws resourcegroupstaggingapi get-resources --tag-filters Key=Project,Values=netsec-study --query 'ResourceTagMappingList[].ResourceARN' --output table` |
| □ | S3 バケット | `aws s3 ls \| grep netsec-study` |
| □ | IAM ユーザ | `aws iam list-users --query "Users[?starts_with(UserName,'netsec-study')].UserName"` |
| □ | ACM 証明書 | `aws acm list-certificates --query 'CertificateSummaryList[].[DomainName,CertificateArn]' --output table` |
| □ | Route 53 ホストゾーン | `aws route53 list-hosted-zones --query 'HostedZones[].Name'` |
| □ | **Inspector（ECRを試した場合）** | `aws inspector2 batch-get-account-status --query 'accounts[].resourceState'` |
| □ | **Security Hub（試した場合）** | `aws securityhub get-enabled-standards` |
| □ | **AWS Config（Security Hubを試した場合）** | `aws configservice describe-configuration-recorder-status` |
| □ | 予算アラート | `aws budgets delete-budget --account-id "$(aws sts get-caller-identity --query Account --output text)" --budget-name netsec-study` |

**Inspector・Security Hub・AWS Config を有効にした場合は、必ず無効に戻してください。** これらは `terraform destroy` の対象外で、有効なままだと課金が続きます。

最後に、翌月の請求でこの学習分の課金が止まっていることを確認して終了です。
