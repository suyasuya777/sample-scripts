#!/usr/bin/env bash
# ALB アクセスログに、12/9・12/11・12/14 の演習で必要な行を作る。
#   ・正常な 200
#   ・アプリが返した 500（elb_status_code と target_status_code が一致）
#   ・ALB が生成した 502（target_status_code が -）
#   ・ターゲット不在の 503（target_processing_time が -1）
#   ・TLS 1.2 と 1.3 の両方でのアクセス（ssl_protocol の分布）
# 使い方: bash scripts/gen_alb_logs.sh
source "$(dirname "$0")/_common.sh"

ALB=$(tfout alb_dns_name)
WEB=$(tfout web_instance_id)

echo "=== 1/5 正常なアクセスを200件"
for i in $(seq 1 200); do curl -s -o /dev/null "http://${ALB}/?i=$i"; done
echo "  完了"

echo "=== 2/5 アプリが返す 500 を20件（elb と target が一致する 5xx）"
for i in $(seq 1 20); do curl -s -o /dev/null "http://${ALB}/status500"; done
echo "  完了"

echo "=== 3/5 ALB が生成する 502 を20件（応答を返さずに切断）"
for i in $(seq 1 20); do curl -s -o /dev/null "http://${ALB}/abort"; done
echo "  完了"

echo "=== 4/5 ターゲット不在の 503 を作る（アプリを止めて再開）"
echo "  アプリを停止"
ssm_run "$WEB" "systemctl stop netsec-app && echo stopped"
echo "  ヘルスチェックが異常になるまで待機（10秒 × 2回 ＋ 余裕）"
sleep 35
echo "  この間のリクエストは 503 になる"
for i in $(seq 1 15); do curl -s -o /dev/null -w "%{http_code} " "http://${ALB}/"; done; echo
echo "  アプリを再開"
ssm_run "$WEB" "systemctl start netsec-app && echo started"
echo "  healthy に戻るまで待機"
sleep 35
curl -s -o /dev/null -w "  復旧確認: %{http_code}\n" "http://${ALB}/"

echo "=== 5/5 HTTPS で TLS 1.2 と 1.3 の両方からアクセス"
for i in $(seq 1 30); do curl -sk --tlsv1.2 --tls-max 1.2 -o /dev/null "https://${ALB}/"; done
for i in $(seq 1 30); do curl -sk --tlsv1.3 -o /dev/null "https://${ALB}/"; done
echo "  完了"

echo
echo "ALB アクセスログの S3 への配信は5分間隔です。"
echo "Athena で検索できるようになるまで、5〜10分待ってください。"
