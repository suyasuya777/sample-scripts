#!/usr/bin/env bash
# web インスタンス上に TIME_WAIT を大量に作る（12/7）。
# 接続を開いてすぐ閉じる＝先に閉じた側に TIME_WAIT が残る。
# 使い方: bash scripts/gen_timewait.sh [接続数（既定3000）]
source "$(dirname "$0")/_common.sh"

WEB=$(tfout web_instance_id)
ALB=$(tfout alb_dns_name)
N="${1:-3000}"

echo "=== 実行前の TIME_WAIT 数"
ssm_run "$WEB" "ss -Htan state time-wait | wc -l"

echo "=== ${N} 本の接続を開いてすぐ閉じる"
ssm_run "$WEB" "python3 -c \"
import socket
for i in range(${N}):
    try:
        s = socket.create_connection(('${ALB}', 80), timeout=5)
        s.close()
    except OSError as e:
        print('stopped at', i, e); break
print('done')
\""

echo "=== 実行後の TIME_WAIT 数（増えていること）"
ssm_run "$WEB" "ss -Htan state time-wait | wc -l; echo '---'; ss -s | head -5"
