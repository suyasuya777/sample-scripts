# 共通関数。各スクリプトから読み込む
set -euo pipefail
TFDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

tfout() { terraform -chdir="$TFDIR" output -raw "$1"; }

# SSM 経由でインスタンス上のコマンドを実行し、出力を表示する
ssm_run() {
  local target="$1" script="$2" cid status
  cid=$(aws ssm send-command \
        --instance-ids "$target" \
        --document-name AWS-RunShellScript \
        --parameters "$(jq -n --arg c "$script" '{commands:[$c]}')" \
        --query 'Command.CommandId' --output text)
  echo "  command-id: $cid（完了まで待機中…）"
  aws ssm wait command-executed --command-id "$cid" --instance-id "$target" 2>/dev/null || true
  status=$(aws ssm get-command-invocation --command-id "$cid" --instance-id "$target" \
           --query 'Status' --output text)
  echo "  status: $status"
  aws ssm get-command-invocation --command-id "$cid" --instance-id "$target" \
    --query 'StandardOutputContent' --output text | sed 's/^/  | /'
  if [ "$status" != "Success" ]; then
    aws ssm get-command-invocation --command-id "$cid" --instance-id "$target" \
      --query 'StandardErrorContent' --output text | sed 's/^/  ! /'
  fi
}
