#!/usr/bin/env bash
# Flow Logs に REJECT の行を作る（12/11）。
# probe から web の「許可されていないポート」へ接続を試みる。
# web のセキュリティグループは ALB からの80番しか許可していないので REJECT になる。
# 使い方: bash scripts/gen_reject.sh
source "$(dirname "$0")/_common.sh"

PROBE=$(tfout probe_instance_id)
WEBIP=$(tfout web_private_ip)
ENI=$(tfout web_eni_id)

echo "=== probe から web(${WEBIP}) の 22 / 80 / 3306 へ接続を試みる"
ssm_run "$PROBE" "for n in 1 2 3 4 5; do for p in 22 80 3306; do timeout 2 bash -c \"</dev/tcp/${WEBIP}/\$p\" 2>/dev/null; echo \"try \$p: exit \$?\"; done; done"

echo
echo "Flow Logs の S3 への配信には最大10分かかります。"
echo "Athena で次の ENI に絞って検索してください: ${ENI}"
