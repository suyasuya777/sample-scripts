terraform {
  required_version = ">= 1.6"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
    tls = {
      source  = "hashicorp/tls"
      version = "~> 4.0"
    }
  }
}

provider "aws" {
  region = var.region

  default_tags {
    tags = {
      Project   = "netsec-study"
      ManagedBy = "terraform"
    }
  }
}

data "aws_caller_identity" "this" {}
data "aws_availability_zones" "this" { state = "available" }
data "aws_elb_service_account" "this" {}

# Amazon Linux 2023（ARM。t4g インスタンス用）
data "aws_ssm_parameter" "al2023_arm" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-arm64"
}

locals {
  name    = var.name_prefix
  account = data.aws_caller_identity.this.account_id
  azs     = slice(data.aws_availability_zones.this.names, 0, 2)
}
