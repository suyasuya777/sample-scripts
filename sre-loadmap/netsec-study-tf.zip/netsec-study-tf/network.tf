# ==================================================================
# ネットワーク
#   12/11 Flow Logs の REJECT 抽出
#   12/15 ルートテーブル・SG・NACL の点検
#   12/16 サブネットの空きIP（/28 を混ぜて逆算の題材にする）
# NAT Gateway は作らない（$1.4/日。EC2 は公開サブネットに置いて SSM で入る）
# ==================================================================

resource "aws_vpc" "this" {
  cidr_block           = "10.30.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags                 = { Name = local.name }
}

resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = local.name }
}

# --- 公開サブネット（ALB と EC2 を置く） ---
resource "aws_subnet" "public" {
  count                   = 2
  vpc_id                  = aws_vpc.this.id
  cidr_block              = cidrsubnet(aws_vpc.this.cidr_block, 8, count.index)
  availability_zone       = local.azs[count.index]
  map_public_ip_on_launch = true
  tags                    = { Name = "${local.name}-public-${count.index}" }
}

# --- 小さいサブネット（12/16 の必要IP数の逆算用。/28 なので使えるのは11個） ---
resource "aws_subnet" "tiny" {
  vpc_id            = aws_vpc.this.id
  cidr_block        = "10.30.9.0/28"
  availability_zone = local.azs[0]
  tags              = { Name = "${local.name}-tiny-28" }
}

# --- NACL の点検用サブネット（12/15。インスタンスは置かない） ---
resource "aws_subnet" "nacl_demo" {
  vpc_id            = aws_vpc.this.id
  cidr_block        = "10.30.9.16/28"
  availability_zone = local.azs[0]
  tags              = { Name = "${local.name}-nacl-demo" }
}

# --- ルートテーブル（最長一致を追う題材として、より具体的な経路も1本入れる） ---
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.this.id
  }

  tags = { Name = "${local.name}-public" }
}

resource "aws_route_table_association" "public" {
  count          = 2
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

# 経路を持たない（VPC内だけで閉じる）ルートテーブル。tiny と nacl-demo に割り当てる
resource "aws_route_table" "isolated" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = "${local.name}-isolated" }
}

resource "aws_route_table_association" "tiny" {
  subnet_id      = aws_subnet.tiny.id
  route_table_id = aws_route_table.isolated.id
}

resource "aws_route_table_association" "nacl_demo" {
  subnet_id      = aws_subnet.nacl_demo.id
  route_table_id = aws_route_table.isolated.id
}

# --- NACL（番号順の評価と、戻りのエフェメラルポート許可を読む題材） ---
resource "aws_network_acl" "demo" {
  vpc_id     = aws_vpc.this.id
  subnet_ids = [aws_subnet.nacl_demo.id]
  tags       = { Name = "${local.name}-demo" }
}

resource "aws_network_acl_rule" "demo_in_http" {
  network_acl_id = aws_network_acl.demo.id
  rule_number    = 100
  egress         = false
  protocol       = "tcp"
  rule_action    = "allow"
  cidr_block     = "0.0.0.0/0"
  from_port      = 80
  to_port        = 80
}

# 22番は明示的に拒否。番号が 100 より後ろなので、80番の許可より後に評価される
resource "aws_network_acl_rule" "demo_in_ssh_deny" {
  network_acl_id = aws_network_acl.demo.id
  rule_number    = 110
  egress         = false
  protocol       = "tcp"
  rule_action    = "deny"
  cidr_block     = "0.0.0.0/0"
  from_port      = 22
  to_port        = 22
}

# 戻りの通信はステートレスなので、送信側にも明示的な許可が要る
resource "aws_network_acl_rule" "demo_out_ephemeral" {
  network_acl_id = aws_network_acl.demo.id
  rule_number    = 100
  egress         = true
  protocol       = "tcp"
  rule_action    = "allow"
  cidr_block     = "0.0.0.0/0"
  from_port      = 1024
  to_port        = 65535
}

# ------------------------------------------------------------------
# セキュリティグループ
# ------------------------------------------------------------------

resource "aws_security_group" "alb" {
  name        = "${local.name}-alb"
  description = "ALB。80/443 を受ける"
  vpc_id      = aws_vpc.this.id

  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "HTTPS"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${local.name}-alb" }
}

# web は ALB からの80番しか受けない。
# probe から web の 22番や 80番を叩くと REJECT になり、Flow Logs に残る（12/11）
resource "aws_security_group" "web" {
  name        = "${local.name}-web"
  description = "ALB からの 80 のみ許可。それ以外は REJECT（Flow Logs の題材）"
  vpc_id      = aws_vpc.this.id

  ingress {
    description     = "HTTP from ALB only"
    from_port       = 80
    to_port         = 80
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${local.name}-web" }
}

resource "aws_security_group" "probe" {
  name        = "${local.name}-probe"
  description = "調査用。受信は許可しない"
  vpc_id      = aws_vpc.this.id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${local.name}-probe" }
}

# ------------------------------------------------------------------
# VPC Flow Logs（S3 へ。既定フォーマット）
# ------------------------------------------------------------------

resource "aws_flow_log" "this" {
  vpc_id               = aws_vpc.this.id
  traffic_type         = "ALL"
  log_destination_type = "s3"
  log_destination      = "${aws_s3_bucket.logs.arn}/flowlogs/"

  depends_on = [aws_s3_bucket_policy.logs]
}
