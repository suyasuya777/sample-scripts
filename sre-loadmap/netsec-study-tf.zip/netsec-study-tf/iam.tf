# ==================================================================
# IAM とシークレット（12/13）
#   ・認証情報レポートで「使用済み／未使用」の差を見るための IAM ユーザ2名
#   ・aws sts assume-role を実際に打つためのロール
#   ・ECS タスク定義から Secrets Manager / SSM を参照する形の見本
# ==================================================================

# ------------------------------------------------------------------
# IAM ユーザ2名（権限は付けない。キーの使用実績の差だけを作る）
#   user1 のキーは構築後に1回だけ使う（手順書の 12/6 の作業）
#   user2 のキーは使わない → 未使用キーとして検出される
# ------------------------------------------------------------------

resource "aws_iam_user" "u1" {
  name          = "${local.name}-user1"
  force_destroy = true
}

resource "aws_iam_user" "u2" {
  name          = "${local.name}-user2"
  force_destroy = true
}

resource "aws_iam_access_key" "u1" {
  user = aws_iam_user.u1.name
}

resource "aws_iam_access_key" "u2" {
  user = aws_iam_user.u2.name
}

# ------------------------------------------------------------------
# AssumeRole の演習用ロール
#   同一アカウント内から引き受けられる。権限は読み取りのみ
# ------------------------------------------------------------------

data "aws_iam_policy_document" "assume_demo" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${local.account}:root"]
    }
  }
}

resource "aws_iam_role" "assume_demo" {
  name                 = "${local.name}-assume-me"
  description          = "12/13 の aws sts assume-role 演習用"
  assume_role_policy   = data.aws_iam_policy_document.assume_demo.json
  max_session_duration = 3600
}

resource "aws_iam_role_policy_attachment" "assume_demo_readonly" {
  role       = aws_iam_role.assume_demo.name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

# ------------------------------------------------------------------
# シークレット（ECS タスク定義から参照する先）
# ------------------------------------------------------------------

resource "aws_secretsmanager_secret" "db" {
  name                    = "${local.name}/db"
  recovery_window_in_days = 0 # destroy で即削除（既定の7日待機を避ける）
}

resource "aws_secretsmanager_secret_version" "db" {
  secret_id     = aws_secretsmanager_secret.db.id
  secret_string = jsonencode({ username = "appuser", password = "StudyOnly12345!" })
}

resource "aws_ssm_parameter" "api_key" {
  name  = "/${local.name}/app/api-key"
  type  = "SecureString"
  value = "study-only-dummy-api-key"
}

# ------------------------------------------------------------------
# ECS タスク定義（登録するだけ。タスクは起動しないので費用はかからない）
#   環境変数ではなく secrets で渡す形の見本
# ------------------------------------------------------------------

data "aws_iam_policy_document" "ecs_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "ecs_exec" {
  name               = "${local.name}-ecs-exec"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume.json
}

resource "aws_iam_role_policy_attachment" "ecs_exec_managed" {
  role       = aws_iam_role.ecs_exec.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# secrets を読むための権限。タスクロールではなく「タスク実行ロール」に付ける
data "aws_iam_policy_document" "ecs_secrets" {
  statement {
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.db.arn]
  }
  statement {
    actions   = ["ssm:GetParameters"]
    resources = [aws_ssm_parameter.api_key.arn]
  }
  statement {
    actions   = ["kms:Decrypt"]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "ecs_secrets" {
  name   = "${local.name}-ecs-secrets"
  role   = aws_iam_role.ecs_exec.id
  policy = data.aws_iam_policy_document.ecs_secrets.json
}

resource "aws_ecs_task_definition" "sample" {
  family                   = local.name
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = "256"
  memory                   = "512"
  execution_role_arn       = aws_iam_role.ecs_exec.arn

  container_definitions = jsonencode([{
    name      = "web"
    image     = "public.ecr.aws/nginx/nginx:alpine"
    essential = true

    # 値そのものはタスク定義に残らない。起動時に取得される
    secrets = [
      { name = "DB_CREDENTIALS", valueFrom = aws_secretsmanager_secret.db.arn },
      { name = "API_KEY", valueFrom = aws_ssm_parameter.api_key.arn },
    ]

    environment = [
      { name = "STAGE", value = "study" },
    ]
  }])

  tags = { Name = local.name }
}
