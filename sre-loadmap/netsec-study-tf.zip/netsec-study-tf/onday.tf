# ==================================================================
# 当日だけ作って当日壊すもの
#   NAT Gateway … 12/7 の ErrorPortAllocation（約 $1.5/日）
#   RDS         … 12/7 の max_connections 検算（約 $0.75/日）
#
# terraform.tfvars は書き換えず、コマンドのオプションで有効にする:
#   作る  : terraform apply -var="enable_nat=true" -var="enable_rds=true"
#   壊す  : terraform apply
# ==================================================================

# ------------------------------------------------------------------
# プライベートサブネット（常時作る。無料）
#   NAT が無い状態では外に出られないので、12/15 の経路の題材にもなる
#   RDS のサブネットグループは2つ以上のAZが必要なので2つ作る
# ------------------------------------------------------------------

resource "aws_subnet" "private" {
  count             = 2
  vpc_id            = aws_vpc.this.id
  cidr_block        = cidrsubnet(aws_vpc.this.cidr_block, 8, count.index + 10)
  availability_zone = local.azs[count.index]
  tags              = { Name = "${local.name}-private-${count.index}" }
}

resource "aws_route_table" "private" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = "${local.name}-private" }
}

resource "aws_route_table_association" "private" {
  count          = 2
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private.id
}

# ------------------------------------------------------------------
# NAT Gateway（enable_nat のときだけ）
# ------------------------------------------------------------------

resource "aws_eip" "nat" {
  count  = var.enable_nat ? 1 : 0
  domain = "vpc"
  tags   = { Name = "${local.name}-nat" }
}

resource "aws_nat_gateway" "this" {
  count         = var.enable_nat ? 1 : 0
  allocation_id = aws_eip.nat[0].id
  subnet_id     = aws_subnet.public[0].id
  tags          = { Name = local.name }

  depends_on = [aws_internet_gateway.this]
}

# この経路が増えることで、プライベートサブネットが外に出られるようになる。
# 12/15 の「最長一致で経路を追う」題材が、より本番に近い形になる
resource "aws_route" "private_nat" {
  count                  = var.enable_nat ? 1 : 0
  route_table_id         = aws_route_table.private.id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.this[0].id
}

# ------------------------------------------------------------------
# RDS
#   パラメータグループは常時作る（無料）。
#   これだけでも max_connections の式は読めるので、
#   インスタンスを作るのは「実際に SHOW max_connections を打ちたい日」だけでよい
# ------------------------------------------------------------------

resource "aws_db_parameter_group" "this" {
  name        = "${local.name}-pg16"
  family      = "postgres16"
  description = "12/7 の max_connections 検算用"

  lifecycle {
    create_before_destroy = true
  }

  tags = { Name = "${local.name}-pg16" }
}

resource "aws_db_subnet_group" "this" {
  name       = local.name
  subnet_ids = aws_subnet.private[*].id
  tags       = { Name = local.name }
}

resource "aws_security_group" "rds" {
  name        = "${local.name}-rds"
  description = "EC2 からの 5432 のみ許可"
  vpc_id      = aws_vpc.this.id

  ingress {
    description     = "PostgreSQL from EC2"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.web.id, aws_security_group.probe.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${local.name}-rds" }
}

resource "aws_db_instance" "this" {
  count = var.enable_rds ? 1 : 0

  identifier             = local.name
  engine                 = "postgres"
  engine_version         = "16"
  instance_class         = "db.t4g.micro"
  allocated_storage      = 20
  storage_type           = "gp3"
  db_name                = "study"
  username               = "postgres"
  password               = var.db_password
  parameter_group_name   = aws_db_parameter_group.this.name
  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.rds.id]

  publicly_accessible     = false
  multi_az                = false
  backup_retention_period = 0    # スナップショットを残さない（消し忘れ防止）
  skip_final_snapshot     = true # これが無いと destroy が止まる
  deletion_protection     = false
  apply_immediately       = true

  tags = { Name = local.name }
}
